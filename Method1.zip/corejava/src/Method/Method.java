package Method;

public class Method {
	public static void main(String[] args) {
		int num1=25;
		int num2=10;
		//method calling
		int c=addition(num1,num2);//num1&num2 parameter
		System.out.println("Sum:"+""+c);
	}
	//declare the method (user defined method)
	public static int addition(int num1,int num2)
	{
		int sum;
		sum = num1+num1;
		return sum;
		
		
	}
	

}
