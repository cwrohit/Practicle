package Method;

public class Defaultcon {
	Defaultcon(){
		System.out.println("Default constructor is  created by rohit");}
		public static void main(String[] args) {
		Defaultcon defaultcon = new Defaultcon();
	
	}
	

}
