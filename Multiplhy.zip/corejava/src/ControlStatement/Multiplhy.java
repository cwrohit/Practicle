package ControlStatement;

public class Multiplhy {

	    public static void main(String[] args) {

	        int num = 9;
	        for(int i = 1; i <= 11; ++i)
	        {
	            System.out.printf("%d * %d = %d \n", num, i, num * i);
	        }
	    }
	}

