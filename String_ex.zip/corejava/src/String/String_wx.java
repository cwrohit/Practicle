package String;

public class String_wx {
 public void show() { // method 1
	 char[] arr = {'r','a','o'}; // char type array
	 System.out.println(arr);
	 String s = new String(arr);
	 System.out.println("value is:"+s);//"rao"
 }
 public void myFunction(){ // method 2
	 String s1= "Rohit";
	 String s3 = "Rao";
	 String s2 = new String(s1);
	 System.out.println(s2);
	 System.out.println(s3);  //Rohit
 }
 public static void main(String[] args) {
	String_wx str = new String_wx();
	str.show();
	str.myFunction();
}
	 
	 
	 
	 
	 
		
	}


