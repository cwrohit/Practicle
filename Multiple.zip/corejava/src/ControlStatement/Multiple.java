package ControlStatement;

public class Multiple {

}
