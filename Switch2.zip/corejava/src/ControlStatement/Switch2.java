package ControlStatement;

public class Switch2 {
	public static void main(String[] args) {
		char ch='a';
		switch (ch) {
		case 'd': System.out.println("kya hall chal hai");
		break;
		case 's': System.out.println("mst tu btya");
		break;
		case 'a': System.out.println("yes i am");
		break;
		default : System.out.println("tere kaam ki na hai");
	}

}
}
