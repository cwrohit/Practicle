package Assignment;
interface New_Employee{
	void salary();
}
interface New_Developer{
	void bonus();
}
class New_Trainer implements New_Employee,New_Developer{
	@Override
	public void salary() {
		System.out.println("salary incremented");
	}
@Override
public void bonus() {
	System.out.println("bonus");
}
}
public class Multiple_Interface2 {
public static void main(String[] args) {
	New_Trainer obj = new New_Trainer();
	obj.salary();
	 New_Trainer obj1 =new  New_Trainer();
	obj.bonus();
}
}
