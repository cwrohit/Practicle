package ControlStatement;

public class Pyramidpattern3
{
public static void main(String[] args)
{
	int rows=2;   
	//Prints upper half pattern  
	for (int i = 0; i <= rows; i++)   
	{  
	for (int j = 0; j <= i; j++)   
	{   
	System.out.print("*");   
	}   
	System.out.println();   
	}   
	//prints lower half pattern  
	for (int i = rows-0; i >= 1; i--)  
	{  
	for (int j = 0; j <= i; j++)  
	{  
	System.out.print("*");  
	}  
	System.out.println();  
	}  
	}  
	  
	
}
