package String;
//check equality by using equal() method
import java.util.Scanner;
public class StringEquality {
	public static void main(String[] args) {
		String str1,str2;
		Scanner ab = new Scanner(System.in);
		System.out.println("ENter first stirng");
		str1 = ab.nextLine();
		System.out.println("Enter second String");
		str2 = ab.nextLine();
		//comparing two input string (java string compare)
	//if (str1.equals (str2))//equals()- compare original content of string
	if(str1==str2)
//== compare reference not value
		if(str1.compareTo(str2)>0)
		System.out.println("Equal string ");
		else
		System.out.println("unequal string");
	}
	

}
