package abstractclass;
abstract class Parent{
	// TODO Auto-generated constructor stub
    Parent(){
    	System.out.println("no-args con");
    	}
    abstract void show();
    void run() {
    	System.out.println("non-abstract methos");
    	
   }
}
class Childabs extends Parent{
	//@override
	void show() {
		System.out.println("parent abstrat methos");
	}
}
public class Abstract {
	public static void main(String[] args) {
		Parent obj = new Childabs();
		obj.show();
		obj.run();
	}

}
