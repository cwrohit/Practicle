package String;

public class ImmutableTest {
  public static void main(String[]abc) {
	  String str = "Rohit";
	  str.concat("Yaduvanshi");
	  str=str.concat("yaduvanshi");
	  System.out.println(str);
	  
	}

}
