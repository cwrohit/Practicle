package ControlStatement;

public class ForEachArray {
public static void main(String[] args) {
	//declare an array
	int arr[]= {22,44,45,47,452};
	//using for each loop for print the array
	for(int i:arr)
	{
		System.out.println(i);
	}
	for(;;)//;; means infiniti times
	{
		System.out.println("chl bhaag yha ss");
	}
}
}
