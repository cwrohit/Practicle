package String;
import java.util.Scanner;

import mypackage.Main;
public class StringTest {
	String x= "Hello";
	public void show() { //method
	Scanner s = new Scanner(System.in);
	System.out.println("Enter String");
	String a = s.next();
	String b = s.next();
	System.out.println(a.length()+b.length());
	System.out.println((a.compareTo(b)>0)?"Yes":"No");
	
System.out.println(a.substring(0,4).toUpperCase()+a.substring(2)+" "+b.substring(0,3).toLowerCase()+b.substring(1));
System.out.println("substring is:"+x.substring(0,3));
System.out.println("Substring is:"+x.substring(2));
}
 public static void main(String[]abc) {
	 StringTest t = new StringTest();
	 t.show();	 
 }	
		}
