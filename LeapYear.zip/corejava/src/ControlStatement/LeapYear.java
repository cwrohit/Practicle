package ControlStatement;

	import java.util.Scanner;
	public class LeapYear {

	  public static void main(String[] args) {

	    Scanner sc= new Scanner(System.in);
	    System.out.println("Enter leap year");
	    int s= sc.nextInt();
	    
	    if(s%4==0)
	    {
	      System.out.println( " this a leap year.");
	    }
	    
	    else
	      System.out.println(" this not a leap year.");
	  }
	}


