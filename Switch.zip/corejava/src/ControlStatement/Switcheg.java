package ControlStatement;

public class Switcheg {
	public static void main(String[] args) 
	{
		int no1=10;
		switch(no1)
		{
		case 1:System.out.println("10");
		break;
		case 2: System.out.println("52");
		break;
		case 3: System.out.println("20");
		break;
		default: System.out.println("tere baski nhi hai😂😂😂😂😂");
		
		}
	}
}
