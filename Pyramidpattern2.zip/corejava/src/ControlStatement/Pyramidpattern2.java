package ControlStatement;

public class Pyramidpattern2 {
	public static void main(String[] args)
	{
		int i,j,number,n=6;
	for( i=0;i<6;i++)
	{
		number=1;
		for( j=0;j<i;j++)
		{
			System.out.print(number+ " ");
			
			number++;
		}
System.out.println();
	}
	

}
}

