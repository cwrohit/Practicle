package RohitJava;

 class Stmethod {
	int rollno;
	String name;
	float fee;
	static String college = "MRK";
	//static method to change the value of static variable
	static void change ()//static method
	{
		college="RPS";
	}
	//constructor
	Stmethod(int rollno,String name,float fee)
	{
		this.rollno=rollno;
		this.name= name;
		this.fee=fee;
	}
	//metohd
	void display() {
	 System.out.println(rollno+" "+name+" "+fee+" "+college);
	}
	public class Staticmethod1  //class2
	{
		public static void main(String[] abc)
		{
			Stmethod.change();
			//calling static method with class name
			Stmethod.change();
			//create object
			Stmethod m1 = new Stmethod(104,"ROhit",80520);
			Stmethod m2 = new Stmethod(105,"Rahul",80520);
			m1.display();
			m2.display();
			
			
		}
		
		
		
		
	}

}
