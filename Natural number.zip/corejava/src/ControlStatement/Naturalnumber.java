package ControlStatement;

public class Naturalnumber {
public static void main(String[] args) {
	int i,num =10,sum=0;
			for(i=1;i<=num;++i)
	{
		sum=sum+i;
	}
	System.out.println("phele 10 natural number hai = "+sum);
	
	
	}
}	


