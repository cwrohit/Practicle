package RohitJava;

public class Staticmethod3 {
	static int add(int a,int b,int c) {
		return a+b*c;
		
	}
	public static void main(String[] args) {
		int d = Staticmethod3.add(25, 44, 458);
		System.out.println(d);
	}

}
