package feblab2;
class Shape1{ //parent class
	void print() { //parent class method
		System.out.println("Print circle");
	}
}
class Size1 extends Shape1{//child class
	void print() { //same method of parent class child(child class method)
		System.out.println("print triangle");}
		void display() {//new method of child class
			System.out.println("print notihng");}
			void show() {
				super.print();
				display();
				super.print();
			}}
public class Supermethod {
public static void main(String[] args) {
	Size1 obj = new Size1();
	obj.show();
}
}
