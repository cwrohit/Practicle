package Assignment;
interface Parentinterface{
	void show(); //by default abstract class
	
}

class Interface1 implements Parentinterface {
	@Override
	public void show() {
		System.out.println("parent interface method");
	}
	public static void main(String[] args) {
		Interface1 obj = new Interface1();
		obj.show();
	}

}
