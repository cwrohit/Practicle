package String;

public class Stringlength {
	public static void main(String[] args) {
		String s = "Rohit Yaduvanshi";
		// one way to find string length
		System.out.println("the string length of '"+s+"' is: "+s.length());
		// get the length of string by another way
		int len = s.length(); //length of the string
		System.out.println("the string length of'"+s+"'+is: "+len);
		
	}

}
