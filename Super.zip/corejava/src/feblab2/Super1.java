package feblab2;
	class Superc{  
		String color=" south african is black";  
		}  
		class Dog extends Superc{  
		String color="indian man is brown";  
		void printColor(){  
		System.out.println( color);//prints color of Dog class  
		System.out.println(super.color);//prints color of Animal class  
		}  
		}  
		class Super1{  
		public static void main(String args[]){  
		Dog d=new Dog();  
		d.printColor();  
		}}  


