package RohitJava;

public class Thiskeyword { //class 1 outer class
	// instance variable
	int id;
	String ename;
    double salary;
    //static String college = "MRK";
    // perametrized constructor
    Thiskeyword(int id, String ename,double salary)
    {
    	this.id=id;
    	this.ename=ename;
    	this.salary=salary;
    }
    	//method
    	void display()
    	{
    		System.out.println(id+ " "+ename+" "+salary);
    	}
    	public class Thiskeyword1 //main class
    	{
    		public static void main (String [] abc)
    		{
    			//object
    			Thiskeyword rd = new Thiskeyword(102,"Rohit",50000);
    			Thiskeyword rd1 = new Thiskeyword(103,"Rahul",80000);
    			rd.display();
    			rd1.display();
    			
    			
    		}
    		
    	}
    
	
	

}
