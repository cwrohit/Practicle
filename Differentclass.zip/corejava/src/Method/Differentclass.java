package Method;

public class Differentclass {
	int age;
	String name;
	void show()
	{
		System.out.println(age+ " " +name);
	}
	public static void main(String[] args) {
		//1st object for name &age
		Differentclass d = new Differentclass();
		//2nd object for name &age
		Differentclass d1 = new Differentclass();
		d.show();
		d1.show();
		Differentclass d3= new Differentclass();
		d3.age=20;
		d3.name="ROHIT YADAV";
		System.out.println(d3.age+d3.name);
		
	}
}
