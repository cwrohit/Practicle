package abstractclass;
abstract class Testabstract{  //abstract method
	abstract void display();
	//non-abstract method
	void show() {
		System.out.println("non abstract method invoked");
	}
}
class Demo1 extends Testabstract{
	//abstract method of parent class
	void display() {
		System.out.println("Demo1 show abstract invoked");	
}}
class Demo2 extends Testabstract{
	void display() {
		System.out.println("Demo 2 abstract invoked");
	}
}
public class AbstractMethod {
	public static void main(String[] args) {
		Demo1 child1 = new Demo1();
		Demo2 child2 = new Demo2();
		child1.display();
		child2.display();
		child2.show();
	}

}
