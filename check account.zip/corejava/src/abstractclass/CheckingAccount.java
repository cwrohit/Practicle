package abstractclass;
abstract class BankAcc{

	
	int account;//instance variable
	int balance;

	abstract void deposite();//abstract method
	abstract void withdraw();//abstract method
	}

	public class CheckingAccount extends BankAcc {//child class
	void deposite() {//implement parent class abstract method
		account=101;
		balance=30000;
		int deposite=1000+balance;
		System.out.println("deposite balance is:"+deposite);
	}
	void withdraw() {//implement the parent class abstract method
		account=102;
		balance=30000;
		int withdraw=balance-1000;
		System.out.println("withdraw balance is:"+withdraw);
	}
		public static void main(String[] args) {//main method
			CheckingAccount ca= new CheckingAccount();//object of child class
		ca.deposite();
		ca.withdraw();
	}
	}




