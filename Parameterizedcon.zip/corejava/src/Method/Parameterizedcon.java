package Method;

import java.security.DomainCombiner;

public class Parameterizedcon {
	int age;
	String name;
	//parameterized cons where we have to pass the peremeter
	Parameterizedcon(int a,String n){
		age=a;
		name=n;
	}
		void show()
		{
			System.out.println(age+" "+name);
			
			}
			public static void main(String[]abc)
			{
				Parameterizedcon d=new Parameterizedcon(21,"ROhit");
				Parameterizedcon d2= new Parameterizedcon(22,"Rahul");
				Parameterizedcon d3 = new Parameterizedcon(24,"Mohit");
				d.show();
				d2.show();
				d3.show();
				
			}
		
	}


