package Method;

public class Defaultparameterized{
	int a;
	int b;
	//Default constructor
	Defaultparameterized(){
	a=120;
	b=25;
}
//parameterized constructor
	Defaultparameterized(int num,int num2){
		a=num;
		b=num2;		
	}
	void show()
	{
		int c= a*b;
		
		System.out.println("divide is :"+c);
	}
	public static void main(String[] args) {
		Defaultparameterized d=new Defaultparameterized(20,10);
		Defaultparameterized d2= new Defaultparameterized();
		d.show();
		d2.show();
		
		
	}
}