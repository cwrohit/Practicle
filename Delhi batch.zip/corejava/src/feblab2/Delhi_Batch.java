package feblab2;

class Batch { //parent class
	int id;
	String name;
	double fee;
	//parent class constructor
	Batch(int id,String name,double fee){
		this.id=id;
		this.name=name;
		this.fee=fee;	
}
}
class BatchMember extends Batch{
	long phoneno; //child class property
	BatchMember(int id,String name,double fee,long phoneno){
		super(id, name, fee);
		this.phoneno=phoneno;	
	}
	void show() {
		System.out.println(id+" "+name+" "+fee+" "+phoneno);	
	}
}
public class Delhi_Batch{
	public static void main(String[] args) {
		BatchMember obj = new BatchMember(1,"Rohit",15000,123525);
		obj.show();
		
	}
}
