package feblab2;
//super keyword --reference variable which refer  
class Shape{  //parent class
	String name= "Circle";
}
class Size extends Shape{
	String name = "no size";
 void print()
 {
	 System.out.println(super.name);
	 System.out.println(name);
	 
 }			
}

public class SuperVI {
	public static void main(String[] args) {
		Size obj = new Size();
		obj.print();
	}

}
