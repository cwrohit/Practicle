package Assignment;
// multiple inheritence - more than one parent class/inheritence
interface Employee{
	void salary();
}
interface Developer{
	void bonus();
}
class Trainer implements Employee,Developer{
	@Override
	public void bonus() {
		System.out.println("bonus will be 10% of salary");
	}
	@Override
	public void salary() {
		System.out.println("salary incremented");
	}
}
public class Multiple_Interface {
	public static void main(String[] args) {
		
	}

}
