package Assignment;
//inheritence with interface
interface Parent{
	void show();
}
interface child extends Parent{
	void display();
}
class Child1 implements child{
	@Override
	public void show() {
		System.out.println("parent interface method");
	}
	@Override
	public void display() {
		System.out.println("Child interface method");
	}
}
public class Inheritence_interface {
public static void main(String[] args) {
	Child1 obj = new Child1();
     obj.display();
     obj.show();
}

}
