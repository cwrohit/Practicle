package RohitJava;

import java.security.DomainCombiner;

public class StaticVariable {
	int rollno;
	String name;
	float fee;
	static String college = "MRK";
	//static void change (){
	//college = "IT";}
	//Constructor
	StaticVariable (int rollno, String name,float fee)
	{
		this.rollno=rollno;
		this.name=name;
		this.fee=fee;
	}
	//metohd
	void display()
	{
	System.out.println(rollno+" "+name+" "+fee+" "+college);
	}
	public class StaticVariable1{//class 2
		public static void main(String[] args) {
			//staticVariable.change();
			//objects
			StaticVariable s1 = new StaticVariable(101,"Rohit",5000);
			StaticVariable s2 = new StaticVariable(102,"Rahul",102);
			s1.display();
			s2.display();
			
		}
	
	}

}
