package ControlStatement;

public class Switch3 {
public static void main(String[] args) {
	String
}
}
